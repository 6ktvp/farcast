import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Loader2, Sparkles, ExternalLink } from "lucide-react";

const Index = () => {
  const [prompt, setPrompt] = useState("");
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      toast.error("Please enter a prompt");
      return;
    }

    setIsGenerating(true);
    setGeneratedImage(null);

    try {
      console.log("Calling generate-art function with prompt:", prompt);
      
      const { data, error } = await supabase.functions.invoke("generate-art", {
        body: { prompt: prompt.trim() },
      });

      if (error) {
        console.error("Edge function error:", error);
        throw error;
      }

      console.log("Function response:", data);

      if (data?.error) {
        throw new Error(data.error);
      }

      // Handle the output - it's typically an array with the image URL
      const imageUrl = Array.isArray(data?.output) 
        ? data.output[0] 
        : data?.output;

      if (imageUrl) {
        setGeneratedImage(imageUrl);
        toast.success("AI art generated successfully!");
      } else {
        throw new Error("No image URL in response");
      }
    } catch (error) {
      console.error("Error generating art:", error);
      toast.error(
        error instanceof Error 
          ? error.message 
          : "Failed to generate art. Please try again."
      );
    } finally {
      setIsGenerating(false);
    }
  };

  const handleMintNFT = () => {
    if (generatedImage) {
      // Open OpenSea in a new tab
      window.open("https://opensea.io", "_blank");
      toast.success("Opening OpenSea to mint your NFT!");
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-2xl space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center gap-2">
            <Sparkles className="w-8 h-8 text-primary animate-pulse" />
            <h1 className="text-5xl font-bold bg-gradient-to-r from-primary via-accent to-secondary bg-clip-text text-transparent">
              AI Art Frame
            </h1>
          </div>
          <p className="text-muted-foreground text-lg">
            Generate stunning AI art from text and mint as NFTs
          </p>
        </div>

        {/* Main Card */}
        <Card className="p-6 bg-card border-border shadow-[var(--glow-purple)]">
          <div className="space-y-6">
            {/* Input Section */}
            <div className="space-y-4">
              <label htmlFor="prompt" className="text-sm font-medium text-foreground">
                Enter your art prompt
              </label>
              <Input
                id="prompt"
                type="text"
                placeholder="A mystical forest with glowing mushrooms under a starry sky..."
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleGenerate()}
                className="bg-background border-border text-foreground placeholder:text-muted-foreground"
                disabled={isGenerating}
              />
            </div>

            {/* Generate Button */}
            <Button
              onClick={handleGenerate}
              disabled={isGenerating || !prompt.trim()}
              className="w-full bg-gradient-to-r from-primary to-accent hover:opacity-90 transition-opacity text-primary-foreground font-semibold py-6 text-lg shadow-[var(--glow-purple)]"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Generating AI Art...
                </>
              ) : (
                <>
                  <Sparkles className="mr-2 h-5 w-5" />
                  Generate AI Art
                </>
              )}
            </Button>

            {/* Generated Image */}
            {generatedImage && (
              <div className="space-y-4 animate-in fade-in duration-500">
                <div className="relative rounded-lg overflow-hidden border border-border shadow-[var(--glow-cyan)]">
                  <img
                    src={generatedImage}
                    alt="Generated AI art"
                    className="w-full h-auto"
                  />
                </div>

                {/* Mint Button */}
                <Button
                  onClick={handleMintNFT}
                  className="w-full bg-gradient-to-r from-secondary to-primary hover:opacity-90 transition-opacity text-secondary-foreground font-semibold py-6 text-lg shadow-[var(--glow-cyan)]"
                >
                  <ExternalLink className="mr-2 h-5 w-5" />
                  Mint as NFT on OpenSea
                </Button>
              </div>
            )}
          </div>
        </Card>

        {/* Footer Info */}
        <div className="text-center text-sm text-muted-foreground">
          <p>Powered by Replicate AI & Farcaster Frames</p>
        </div>
      </div>
    </div>
  );
};

export default Index;
